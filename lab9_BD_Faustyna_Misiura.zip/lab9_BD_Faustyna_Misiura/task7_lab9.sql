CREATE DATABASE StaraBazaDanych
CREATE TABLE NepotrzebnaTabela( NiepotrzebnaKolumna INT )