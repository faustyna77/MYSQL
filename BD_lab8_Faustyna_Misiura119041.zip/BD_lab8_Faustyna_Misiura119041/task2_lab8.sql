SELECT NazwaProduktu FROM sklep_internetowy.Produkty WHERE
Cena>( SELECT  AVG(Cena) FROM sklep_internetowy.Produkty)
