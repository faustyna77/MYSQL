SELECT * FROM sklep_internetowy.Klienci 
WHERE IDKlienta IN (SELECT IDKlienta FROM sklep_internetowy.Zamowienia)