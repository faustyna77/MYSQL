SELECT * FROM sklep_internetowy.Klienci 
JOIN sklep_internetowy.Zamowienia ON Zamowienia.IDKlienta=Klienci.IDKlienta