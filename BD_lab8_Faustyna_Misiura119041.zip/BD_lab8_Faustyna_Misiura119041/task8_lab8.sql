SELECT * FROM sklep_internetowy.Produkty WHERE Cena<(SELECT AVG(Cena) FROM sklep_internetowy.Produkty
													)AND Cena>30