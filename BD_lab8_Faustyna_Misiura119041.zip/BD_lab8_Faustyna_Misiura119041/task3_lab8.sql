SELECT Imie,Nazwisko FROM sklep_internetowy.Klienci WHERE 
IDKlienta=(SELECT IDKlienta FROM sklep_internetowy.Zamowienia 
		   WHERE IDZamowienia=(SELECT IDZamowienia FROM sklep_internetowy.PozycjeZamowienia
		   JOIN sklep_internetowy.Produkty ON Produkty.IDProduktu=PozycjeZamowienia.IDProduktu WHERE
							  Cena>1000))
