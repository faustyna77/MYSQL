SELECT * FROM sklep_internetowy.Klienci WHERE NOT EXISTS (SELECT 1 FROM sklep_internetowy.Zamowienia
														 WHERE IDKlienta=Klienci.IDKlienta)