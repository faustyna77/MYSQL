SELECT Imie, Nazwisko FROM sklep_internetowy.Klienci 
WHERE IDklienta =
(SELECT IDKlienta FROM sklep_internetowy.Zamowienia WHERE 
IDZamowienia = (SELECT IDZamowienia FROM sklep_internetowy.PozycjeZamowienia JOIN sklep_internetowy.Produkty
ON Produkty.IDProduktu=Pozycjezamowienia.IDProduktu WHERE NazwaProduktu='Tablet'))