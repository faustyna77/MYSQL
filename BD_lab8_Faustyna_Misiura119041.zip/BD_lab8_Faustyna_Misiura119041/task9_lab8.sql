SELECT IDZamowienia, COUNT(*) AS liczbazamowien FROM sklep_internetowy.PozycjeZamowienia 
GROUP BY IDZamowienia HAVING COUNT(*)>2