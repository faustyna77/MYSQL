SELECT IDZamowienia FROM sklep_internetowy.Zamowienia WHERE IDZamowienia
 IN (SELECT IDZamowienia FROM  sklep_internetowy.PozycjeZamowienia JOIN sklep_internetowy.Produkty
 ON Produkty.IDProduktu=PozycjeZamowienia.IDProduktu WHERE Cena>50)