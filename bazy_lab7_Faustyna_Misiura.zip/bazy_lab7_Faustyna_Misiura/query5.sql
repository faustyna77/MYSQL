--SELECT Produkty.NazwaProduktu, Produkty.Cena,PozycjeZamowienia.Ilosc
--FROM sklep_internetowy.Produkty
--INNER JOIN sklep_internetowy.PozycjeZamowienia ON PozycjeZamowienia.IDProduktu=Produkty.IDProduktu


SELECT Produkty.NazwaProduktu,Produkty.Cena,Zamowienia.IDZamowienia, PozycjeZamowienia.ilosc
FROM sklep_internetowy.Produkty
INNER JOIN sklep_internetowy.PozycjeZamowienia ON Produkty.IDProduktu=PozycjeZamowienia.IDProduktu
INNER JOIN sklep_internetowy.Zamowienia ON  Zamowienia.IDZamowienia=PozycjeZamowienia.IDZamowienia

