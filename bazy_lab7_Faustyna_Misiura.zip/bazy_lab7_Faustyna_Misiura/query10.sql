SELECT Produkty.NazwaProduktu
FROM sklep_internetowy.Produkty 
INNER JOIN sklep_internetowy.PozycjeZamowienia ON Produkty.IDProduktu=PozycjeZamowienia.IDProduktu
WHERE PozycjeZamowienia.IDZamowienia IS NULL 
----