SELECT Klienci.Imie, Klienci.Nazwisko,PozycjeZamowienia.ilosc
FROM sklep_internetowy.Klienci
LEFT JOIN sklep_internetowy.Zamowienia ON Zamowienia.IDKlienta=Klienci.IDKlienta
LEFT JOIN sklep_internetowy.PozycjeZamowienia ON PozycjeZamowienia.IDZamowienia=Zamowienia.IDZamowienia
WHERE PozycjeZamowienia.ilosc IS NULL
