SELECT COUNT(pz.ilosc) AS ilosczamowien , p.NazwaProduktu
FROM sklep_internetowy.PozycjeZamowienia pz 
RIGHT JOIN sklep_internetowy.Produkty p  ON pz.IDProduktu=p.IDProduktu
RIGHT JOIN sklep_internetowy.Zamowienia z ON z.IDZamowienia=pz.IDZamowienia
GROUP BY p.NazwaProduktu