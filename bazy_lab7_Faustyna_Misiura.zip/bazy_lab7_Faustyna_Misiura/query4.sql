--SELECT Zamowienia.IDZamowienia, Zamowienia.IDKlienta, Klienci.Imie,Klienci.Nazwisko
--FROM sklep_internetowy.Zamowienia
--INNER JOIN sklep_internetowy.Klienci ON Klienci.IDKlienta=Zamowienia.IDKlienta
--ORDER  BY Klienci.Imie


SELECT Klienci.Imie,Klienci.Nazwisko,Zamowienia.IDZamowienia
FROM sklep_internetowy.Klienci
INNER JOIN sklep_internetowy.Zamowienia ON Zamowienia.IDKlienta=Klienci.IDKlienta
