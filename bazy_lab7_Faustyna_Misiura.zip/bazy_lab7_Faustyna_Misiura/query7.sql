SELECT Klienci.Imie,Klienci.Nazwisko,Produkty.NazwaProduktu
FROM sklep_internetowy.Klienci
INNER JOIN sklep_internetowy.Zamowienia ON Zamowienia.IDKlienta=Klienci.IDKlienta
INNER JOIN sklep_internetowy.PozycjeZamowienia ON PozycjeZamowienia.IDZamowienia=Zamowienia.IDZamowienia
INNER JOIN sklep_internetowy.Produkty ON Produkty.IDProduktu=PozycjeZamowienia.IDProduktu

