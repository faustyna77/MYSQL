SELECT  z.IDZamowienia, z.DataZamowienia,k.Imie,k.Nazwisko,k.IDKlienta
FROM  sklep_internetowy.Zamowienia z 
INNER JOIN sklep_internetowy.Klienci k
ON z.IDKlienta=k.IDKlienta
WHERE z.DataZamowienia BETWEEN '2023-01-01' AND'2023-06-12'