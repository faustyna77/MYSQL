SELECT DISTINCT  Klienci.Imie,Klienci.Nazwisko, Zamowienia.IDZamowienia
FROM sklep_internetowy.Klienci 
RIGHT JOIN sklep_internetowy.Zamowienia ON Zamowienia.IDKlienta=Klienci.IDKlienta 
RIGHT JOIN sklep_internetowy.PozycjeZamowienia ON PozycjeZamowienia.IDZamowienia=Zamowienia.IDZamowienia