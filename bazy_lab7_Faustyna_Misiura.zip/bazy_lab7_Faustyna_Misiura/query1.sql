SELECT Klienci.Imie,Klienci.Nazwisko, Klienci.Email,Klienci.IDKlienta,PozycjeZamowienia.ilosc
FROM sklep_internetowy.Klienci 
 RIGHT JOIN sklep_internetowy.Zamowienia ON Klienci.IDKlienta=Zamowienia.IDKlienta
RIGHT JOIN sklep_internetowy.PozycjeZamowienia ON Zamowienia.IDZamowienia=PozycjeZamowienia.IDZamowienia