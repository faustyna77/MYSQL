CREATE VIEW sklep_internetowy.Pozycja_widok AS
SELECT Produkty.NazwaProduktu, COUNT(PozycjeZamowienia.Ilosc) AS ilosc
FROM sklep_internetowy.Produkty
JOIN sklep_internetowy.PozycjeZamowienia
ON PozycjeZamowienia.IDProduktu=Produkty.IDProduktu
GROUP BY Produkty.IDProduktu
ORDER BY ilosc DESC