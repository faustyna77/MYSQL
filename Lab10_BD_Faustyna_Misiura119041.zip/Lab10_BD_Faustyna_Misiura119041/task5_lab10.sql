CREATE VIEW sklep_internetowy.Suma_wartosci AS
SELECT DATE_TRUNC('month',Zamowienia.DataZamowienia) AS wartosc
FROM sklep_internetowy.Zamowienia 
JOIN sklep_internetowy.PozycjeZamowienia 
ON Zamowienia.IDZamowienia=PozycjeZamowienia.IDZamowienia
JOIN sklep_internetowy.Produkty 
ON PozycjeZamowienia.IDProduktu =Produkty.IDProduktu 
GROUP BY wartosc
SELECT * FROM sklep_internetowy.Suma_wartosci