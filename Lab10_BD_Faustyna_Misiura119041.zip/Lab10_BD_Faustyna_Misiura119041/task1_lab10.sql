CREATE VIEW sklep_internetowy.LiczbaZamowien AS
SELECT Imie,Nazwisko,COUNT(PozycjeZamowienia.IDZamowienia) AS Ilosc FROM sklep_internetowy.Klienci
JOIN sklep_internetowy.Zamowienia
ON Zamowienia.IDKlienta=Klienci.IDKlienta
JOIN sklep_internetowy.PozycjeZamowienia
ON PozycjeZamowienia.IDZamowienia=Zamowienia.IDZamowienia
GROUP BY Klienci.Imie,Klienci.Nazwisko