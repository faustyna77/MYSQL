/*CREATE VIEW sklep_internetowy.ListaPoz AS
SELECT Produkty.NazwaProduktu, PozycjeZamowienia.Ilosc
FROM sklep_internetowy.Produkty 
JOIN sklep_internetowy.PozycjeZamowienia
ON Produkty.IDProduktu=PozycjeZamowienia.IDProduktu*/

SELECT * FROM sklep_internetowy.ListaPoz
